package com.MosIC.MosIC_Office.customers.service;

import com.MosIC.MosIC_Office.customers.dto.CustomerDTO;
import com.MosIC.MosIC_Office.customers.entity.CustomerEntity;
import com.MosIC.MosIC_Office.customers.mapper.CustomerMapper;
import com.MosIC.MosIC_Office.customers.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerServicesImp implements CustomerServices {

    private final CustomerRepository customerRepository;

    public CustomerServicesImp(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    // ── CREATE ────────────────────────────────────────────────────────────────
    @Override
    public CustomerDTO createCustomer(CustomerDTO customerDTO) {
        CustomerEntity entity = CustomerMapper.mapToEntity(customerDTO);
        entity.setId(null); // ✅ force null so IDENTITY generates it
        CustomerEntity saved = customerRepository.save(entity);
        return CustomerMapper.mapToDTO(saved);
    }

    // ── GET BY ID ─────────────────────────────────────────────────────────────
    @Override
    public CustomerDTO getCustomerById(Long id) {
        CustomerEntity entity = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));
        return CustomerMapper.mapToDTO(entity);
    }

    // ── GET ALL ───────────────────────────────────────────────────────────────
    @Override
    public List<CustomerDTO> getAllCustomers() {
        return customerRepository.findAll()
                .stream()
                .map(CustomerMapper::mapToDTO)
                .collect(Collectors.toList());
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────
    @Override
    public CustomerDTO updateCustomer(Long id, CustomerDTO customerDTO) {
        CustomerEntity entity = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));

        entity.setName(customerDTO.getNAME());
        entity.setBuyerAddress1(customerDTO.getBUYER_ADDRESS_1());
        entity.setBuyerAddress2(customerDTO.getBUYER_ADDRESS_2());
        entity.setBuyerAddress3(customerDTO.getBUYER_ADDRESS_3());
        entity.setShippingAddress1(customerDTO.getSHIPPING_ADDRESS_1());
        entity.setShippingAddress2(customerDTO.getSHIPPING_ADDRESS_2());
        entity.setShippingAddress3(customerDTO.getSHIPPING_ADDRESS_3());
        entity.setWebsite(customerDTO.getWEBSITE());
        entity.setGmailId(customerDTO.getGMAILID());
        entity.setContact(customerDTO.getCONTACT());
        entity.setCin(customerDTO.getCIN());
        entity.setGst(customerDTO.getGST());
        entity.setPan(customerDTO.getPAN());
        entity.setTan(customerDTO.getTAN());

        entity.setBankAccHolder(customerDTO.getBANKACCHOLDER());
        entity.setBankName(customerDTO.getBANKNAME());
        entity.setAccNumber(customerDTO.getACCNUMBER());

        entity.setMicrCode(customerDTO.getMICRCODE());
        entity.setIfscCode(customerDTO.getIFSCCODE());
        entity.setCSwiftCode(customerDTO.getC_SWIFT_CODE());

        entity.setCBankCode(customerDTO.getC_BANKCODE());
        entity.setCIban(customerDTO.getC_IBAN());
        entity.setCBankBranchAdd1(customerDTO.getC_BANKBRANCH_ADD_1());
        entity.setCBankBranchAdd2(customerDTO.getC_BANKBRANCH_ADD_2());
        entity.setCBankBranchAdd3(customerDTO.getC_BANKBRANCH_ADD_3());
        entity.setCustType(customerDTO.getCUST_TYPE());
        entity.setStatus(customerDTO.getSTATUS());

        return CustomerMapper.mapToDTO(customerRepository.save(entity));
    }

    // ── DELETE ────────────────────────────────────────────────────────────────
    @Override
    public void deleteCustomer(Long id) {
        CustomerEntity entity = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));
        customerRepository.delete(entity);
    }
}
