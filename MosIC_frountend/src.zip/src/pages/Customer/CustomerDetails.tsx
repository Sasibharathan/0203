import { type FormEvent, useCallback, useEffect, useState } from "react";
import PageMeta from "../../components/common/PageMeta";
import PageBreadcrumb from "../../components/common/PageBreadCrumb";
import ComponentCard from "../../components/common/ComponentCard";
import Label from "../../components/form/Label";
import Input from "../../components/form/input/InputField";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../../components/ui/table";
import { Modal } from "../../components/ui/modal";
import axiosInstance from "../../utils/axiosInstance";
import PartyDetails from "./PartyDetails";

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS & STYLES
// ─────────────────────────────────────────────────────────────────────────────

const CUSTOMER_URL = "/api/customers";

const selectClass =
  "h-10 w-full rounded-lg border border-gray-300 bg-white px-3 text-sm text-gray-800 outline-none transition-colors focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white";

// ─────────────────────────────────────────────────────────────────────────────
// TYPES - Match backend CustomerDTO exactly
// ─────────────────────────────────────────────────────────────────────────────

type CustomerDTO = {
  id: number | null;
  name: string;
  buyerAddress1: string;
  buyerAddress2: string;
  buyerAddress3: string;
  shippingAddress1: string;
  shippingAddress2: string;
  shippingAddress3: string;
  website: string;
  gmailId: string;
  contact: string;
  cin: string;
  gst: string;
  pan: string;
  tan: string;
  bankAccHolder: string;
  bankName: string;
  accNumber: string;
  micrCode: string;
  ifscCode: string;  // ✅ CRITICAL: camelCase, NOT NULL
  cSwiftCode: string;
  cBankCode: string;
  cIban: string;
  cBankBranchAdd1: string;
  cBankBranchAdd2: string;
  cBankBranchAdd3: string;
  custType: string;   // "1" = Local, "2" = International
  status: number;     // 1 = Active, 0 = Inactive
  cGstLutNo: string;
};

// ─────────────────────────────────────────────────────────────────────────────
// HELPER FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

const createEmptyForm = (): CustomerDTO => ({
  id: null,
  name: "",
  buyerAddress1: "",
  buyerAddress2: "",
  buyerAddress3: "",
  shippingAddress1: "",
  shippingAddress2: "",
  shippingAddress3: "",
  website: "",
  gmailId: "",
  contact: "",
  cin: "",
  gst: "",
  pan: "",
  tan: "",
  bankAccHolder: "",
  bankName: "",
  accNumber: "",
  micrCode: "",
  ifscCode: "", // ✅ CRITICAL: Must be present
  cSwiftCode: "",
  cBankCode: "",
  cIban: "",
  cBankBranchAdd1: "",
  cBankBranchAdd2: "",
  cBankBranchAdd3: "",
  custType: "1",
  status: 1,
  cGstLutNo: "",
});

const getAxiosErrorMessage = (err: unknown): string => {
  if (err && typeof err === "object" && "response" in err) {
    const res = (err as any).response;
    return res?.data?.message ?? res?.data?.error ?? "An error occurred";
  }
  return "Network error — please try again";
};

// ── GST LUT expiry helper ─────────────────────────────────────────────────────

type LutStatus =
  | { type: "expired";  daysAgo: number }
  | { type: "warning";  daysLeft: number }
  | { type: "ok" }
  | { type: "none" };

const getLutStatus = (expiryDate: string): LutStatus => {
  if (!expiryDate) return { type: "none" };
  const today  = new Date(); today.setHours(0, 0, 0, 0);
  const expiry = new Date(expiryDate); expiry.setHours(0, 0, 0, 0);
  const diffMs   = expiry.getTime() - today.getTime();
  const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));
  if (diffDays < 0)   return { type: "expired", daysAgo: Math.abs(diffDays) };
  if (diffDays <= 30) return { type: "warning", daysLeft: diffDays };
  return { type: "ok" };
};

// ─────────────────────────────────────────────────────────────────────────────
// BADGE COMPONENTS
// ─────────────────────────────────────────────────────────────────────────────

const StatusBadge = ({ status }: { status: number }) => {
  const isActive = status === 1;
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${
        isActive
          ? "bg-green-50 text-green-700 dark:bg-green-500/10 dark:text-green-400"
          : "bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400"
      }`}
    >
      <span className={`size-1.5 rounded-full ${isActive ? "bg-green-500" : "bg-gray-400"}`} />
      {isActive ? "Active" : "Inactive"}
    </span>
  );
};

const CustTypeBadge = ({ type }: { type: string }) => (
  <span
    className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
      type === "1"
        ? "bg-blue-50 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400"
        : "bg-purple-50 text-purple-700 dark:bg-purple-500/10 dark:text-purple-400"
    }`}
  >
    {type === "1" ? "Local" : "International"}
  </span>
);

const SectionHeading = ({ title }: { title: string }) => (
  <div className="col-span-full mb-2 mt-3 border-b border-gray-200 pb-2 dark:border-gray-700">
    <p className="text-xs font-semibold uppercase tracking-widest text-gray-500 dark:text-gray-400">
      {title}
    </p>
  </div>
);

// ─────────────────────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────────────────

export default function CustomerDetails() {

  const [rows, setRows] = useState<CustomerDTO[]>([]);
  const [formState, setFormState] = useState<CustomerDTO>(createEmptyForm());
  const [editingId, setEditingId] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [formError, setFormError] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Partial<Record<keyof CustomerDTO, string>>>({});

  // ── UI-only: GST LUT expiry date (not part of DTO) ────────────────────────
  const [lutExpiry, setLutExpiry] = useState("");
  const lutStatus = getLutStatus(lutExpiry);

  // ─── Parties modal state ───────────────────────────────────────────────────
  const [partiesModal, setPartiesModal] = useState<{
    open: boolean;
    customerId: number | null;
    customerName: string;
  }>({ open: false, customerId: null, customerName: "" });

  const isEditing = editingId !== null;
  const clearMessages = () => {
    setErrorMessage("");
    setSuccessMessage("");
    setFormError("");
    setFieldErrors({});
  };

  const setField = <K extends keyof CustomerDTO>(f: K, v: CustomerDTO[K]) =>
    setFormState((p) => ({ ...p, [f]: v }));

  // ─── FETCH CUSTOMERS ───────────────────────────────────────────────────────

  const fetchCustomers = useCallback(async () => {
    setIsLoading(true);
    clearMessages();
    try {
      const { data } = await axiosInstance.get<CustomerDTO[]>(CUSTOMER_URL);
      setRows(Array.isArray(data) ? data : data ?? []);
    } catch (err) {
      setErrorMessage(getAxiosErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchCustomers();
  }, [fetchCustomers]);

  // ─── FORM HANDLERS ─────────────────────────────────────────────────────────

  const openNewForm = () => {
    setFormState(createEmptyForm());
    setEditingId(null);
    setShowForm(true);
    setLutExpiry("");
    clearMessages();
  };

  const openEditForm = (row: CustomerDTO) => {
    setFormState(row);
    setEditingId(row.id);
    setShowForm(true);
    setLutExpiry("");
    clearMessages();
  };

  const handleCancelForm = () => {
    setShowForm(false);
    setFormState(createEmptyForm());
    setEditingId(null);
    setLutExpiry("");
  };

  const handleSubmitForm = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFormError("");
    setFieldErrors({});
    setSuccessMessage("");

    // ✅ FULL FIELD VALIDATION
    const errs: Partial<Record<keyof CustomerDTO, string>> = {};
    const isLocal = formState.custType === "1";
    const isIntl  = formState.custType === "2";

    // ── Basic Info ────────────────────────────────────────────────────────────
    if (!formState.name.trim())    errs.name    = "Company name is required";
    if (!formState.contact.trim()) errs.contact = "Contact number is required";
    if (!formState.gmailId.trim()) errs.gmailId = "Email is required";
    else if (!formState.gmailId.includes("@")) errs.gmailId = "Invalid email format";
    if (!formState.custType)       errs.custType = "Customer type is required";

    // ── Addresses ─────────────────────────────────────────────────────────────
    if (!formState.buyerAddress1.trim())    errs.buyerAddress1    = "Buyer address line 1 is required";
    if (!formState.shippingAddress1.trim()) errs.shippingAddress1 = "Shipping address line 1 is required";

    // ── Tax & Compliance ──────────────────────────────────────────────────────
    if (!formState.gst.trim()) errs.gst = "GST number is required";
    if (!formState.pan.trim()) errs.pan = "PAN is required";

    // ── Bank Details — always required ─────────────────────────────────────────
    if (!formState.bankAccHolder.trim()) errs.bankAccHolder = "Account holder name is required";
    if (!formState.bankName.trim())      errs.bankName      = "Bank name is required";
    if (!formState.accNumber.trim())     errs.accNumber     = "Account number is required";

    // ── India-specific bank fields (Local customers) ──────────────────────────
    if (isLocal) {
      if (!formState.ifscCode.trim())         errs.ifscCode = "IFSC code is required";
      else if (formState.ifscCode.length < 11) errs.ifscCode = "IFSC code must be 11 characters (e.g., HDFC0001234)";
    }

    // ── International bank fields (International customers) ───────────────────
    if (isIntl) {
      if (!formState.cSwiftCode.trim())      errs.cSwiftCode      = "SWIFT code is required for international customers";
      if (!formState.cBankCode.trim())       errs.cBankCode       = "Bank code is required for international customers";
      if (!formState.cIban.trim())           errs.cIban           = "IBAN is required for international customers";
      if (!formState.cBankBranchAdd1.trim()) errs.cBankBranchAdd1 = "Bank branch address is required for international customers";
    }

    if (Object.keys(errs).length > 0) {
      setFieldErrors(errs);
      setFormError("Please fill in all required fields before submitting.");
      return;
    }

    setIsSubmitting(true);
    const payload: Partial<CustomerDTO> = { ...formState };

    try {
      if (isEditing && editingId !== null) {
        await axiosInstance.put(`${CUSTOMER_URL}/${editingId}`, payload);
        setSuccessMessage("Customer updated successfully");
      } else {
        delete payload.id;
        await axiosInstance.post(CUSTOMER_URL, payload);
        setSuccessMessage("Customer created successfully");
      }

      await fetchCustomers();
      setShowForm(false);
      setFormState(createEmptyForm());
      setEditingId(null);
    } catch (err) {
      console.error("Backend Error Detail:", err);
      setFormError(getAxiosErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm("Are you sure you want to delete this customer?")) return;

    setIsSubmitting(true);
    clearMessages();
    try {
      await axiosInstance.delete(`${CUSTOMER_URL}/${id}`);
      setSuccessMessage("Customer deleted successfully");
      await fetchCustomers();
    } catch (err) {
      setErrorMessage(getAxiosErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOpenParties = (customer: CustomerDTO) => {
    setPartiesModal({
      open: true,
      customerId: customer.id!,
      customerName: customer.name,
    });
  };

  // ─────────────────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────────────────

  return (
    <>
      <PageMeta title="Customers" description="Manage customer details and contacts" />
      <PageBreadcrumb items={[{ label: "Dashboard" }, { label: "Customers" }]} />

      <ComponentCard>
        {/* Header */}
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Customers</h1>
            <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
              Manage companys information and contacts
            </p>
          </div>
          <button
            onClick={openNewForm}
            disabled={isSubmitting}
            className="inline-flex items-center gap-2 rounded-md bg-brand-500 px-3 py-1.5 font-medium text-white hover:bg-brand-600 disabled:opacity-50 dark:bg-brand-600 dark:hover:bg-brand-700"
          >
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Add Customer
          </button>
        </div>

        {/* Messages */}
        {errorMessage && (
          <div className="mb-4 rounded border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700 dark:border-red-500/20 dark:bg-red-500/10 dark:text-red-400">
            {errorMessage}
          </div>
        )}
        {successMessage && (
          <div className="mb-4 rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700 dark:border-green-500/20 dark:bg-green-500/10 dark:text-green-400">
            {successMessage}
          </div>
        )}

        {/* ── Parties Modal ───────────────────────────────────────────────── */}
        <Modal
          isOpen={partiesModal.open}
          onClose={() => setPartiesModal({ open: false, customerId: null, customerName: "" })}
          className="mx-4 w-full max-w-4xl p-4 sm:p-6"
        >
          {/* Modal header */}
          <div className="mb-4 flex items-center gap-3 border-b border-gray-100 pb-4 dark:border-gray-800">
            <span className="flex size-9 items-center justify-center rounded-lg bg-teal-50 dark:bg-teal-500/10">
              <svg
                className="size-5 text-teal-600 dark:text-teal-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={1.8}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M17 20h5v-2a4 4 0 00-4-4h-1M9 20H4v-2a4 4 0 014-4h1m4-4a4 4 0 100-8 4 4 0 000 8zm6 4a3 3 0 11-6 0 3 3 0 016 0z"
                />
              </svg>
            </span>
            <div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
                Party Contacts
              </h3>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {partiesModal.customerName}
              </p>
            </div>
          </div>

          {/* Render PartyDetails in modal mode */}
          {partiesModal.customerId !== null && (
            <PartyDetails
              customerIdProp={partiesModal.customerId}
              customerNameProp={partiesModal.customerName}
              isModal
            />
          )}
        </Modal>

        {/* ── Customer Form Modal ─────────────────────────────────────────── */}
        <Modal isOpen={showForm} onClose={handleCancelForm} className="mx-4 w-full max-w-4xl p-4 sm:p-6">
          <h3 className="pr-12 text-xl font-semibold text-gray-800 dark:text-white/90">
            {isEditing ? "Edit Customer" : "Add New Customer"}
          </h3>
          <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
            {isEditing
              ? "Update customer information and bank details"
              : "Create a new customer profile with complete details"}
          </p>

          {/* ── In-modal error toast ── */}
          {formError && (
            <div className="mt-4 flex items-start justify-between gap-2 rounded border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700 dark:border-red-500/20 dark:bg-red-500/10 dark:text-red-400">
              <span>{formError}</span>
              <button
                type="button"
                onClick={() => setFormError("")}
                className="shrink-0 text-red-400 hover:text-red-600 dark:text-red-500 dark:hover:text-red-300"
                aria-label="Dismiss"
              >
                ✕
              </button>
            </div>
          )}

          <form onSubmit={(e) => void handleSubmitForm(e)} className="mt-4">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {/* SECTION: Basic Information */}
              <SectionHeading title="Basic Information" />

              <div>
                <Label htmlFor="name">
                  Company Name <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="name"
                  value={formState.name}
                  onChange={(e) => {
                    setField("name", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, name: undefined }));
                  }}
                  placeholder="Company or organization name"
                  disabled={isSubmitting}
                  className={fieldErrors.name ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.name && <p className="mt-1 text-xs text-red-500">{fieldErrors.name}</p>}
              </div>

              <div>
                <Label htmlFor="contact">
                  Contact Number <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="contact"
                  value={formState.contact}
                  onChange={(e) => {
                    setField("contact", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, contact: undefined }));
                  }}
                  placeholder="Phone number"
                  disabled={isSubmitting}
                  className={fieldErrors.contact ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.contact && <p className="mt-1 text-xs text-red-500">{fieldErrors.contact}</p>}
              </div>

              <div>
                <Label htmlFor="gmailId">
                  Email <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="gmailId"
                  type="email"
                  value={formState.gmailId}
                  onChange={(e) => {
                    setField("gmailId", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, gmailId: undefined }));
                  }}
                  placeholder="company@email.com"
                  disabled={isSubmitting}
                  className={fieldErrors.gmailId ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.gmailId && <p className="mt-1 text-xs text-red-500">{fieldErrors.gmailId}</p>}
              </div>

              <div>
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  value={formState.website}
                  onChange={(e) => setField("website", e.target.value)}
                  placeholder="www.example.com"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="custType">
                  Customer Type <span className="text-red-500">*</span>
                </Label>
                <select
                  id="custType"
                  className={`${selectClass}${fieldErrors.custType ? " border-red-500 ring-2 ring-red-500/20" : ""}`}
                  value={formState.custType}
                  onChange={(e) => {
                    setField("custType", e.target.value);
                    if (e.target.value) setFieldErrors((p) => ({ ...p, custType: undefined }));
                  }}
                  disabled={isSubmitting}
                >
                  <option value="1">Local</option>
                  <option value="2">International</option>
                </select>
                {fieldErrors.custType && <p className="mt-1 text-xs text-red-500">{fieldErrors.custType}</p>}
              </div>

              <div>
                <Label htmlFor="status">
                  Status <span className="text-red-500">*</span>
                </Label>
                {isEditing ? (
                  <select
                    id="status"
                    className={selectClass}
                    value={formState.status}
                    onChange={(e) => setField("status", parseInt(e.target.value))}
                    disabled={isSubmitting}
                  >
                    <option value={1}>Active</option>
                    <option value={0}>Inactive</option>
                  </select>
                ) : (
                  <div className="flex h-10 items-center">
                    <span className="inline-flex items-center gap-1 rounded-full bg-green-50 px-3 py-1 text-sm font-medium text-green-700 dark:bg-green-500/10 dark:text-green-400">
                      <span className="size-1.5 rounded-full bg-green-500" />
                      Active
                    </span>
                    <input type="hidden" name="status" value={1} />
                  </div>
                )}
              </div>

              {/* SECTION: Buyer Address */}
              <SectionHeading title="Buyer Address" />

              <div>
                <Label htmlFor="buyerAddress1">Address Line 1 <span className="text-red-500">*</span></Label>
                <Input
                  id="buyerAddress1"
                  value={formState.buyerAddress1}
                  onChange={(e) => {
                    setField("buyerAddress1", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, buyerAddress1: undefined }));
                  }}
                  placeholder="Street address"
                  disabled={isSubmitting}
                  className={fieldErrors.buyerAddress1 ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.buyerAddress1 && <p className="mt-1 text-xs text-red-500">{fieldErrors.buyerAddress1}</p>}
              </div>

              <div>
                <Label htmlFor="buyerAddress2">Address Line 2</Label>
                <Input
                  id="buyerAddress2"
                  value={formState.buyerAddress2}
                  onChange={(e) => setField("buyerAddress2", e.target.value)}
                  placeholder="Apartment, suite, etc."
                  disabled={isSubmitting}
                />
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="buyerAddress3">Address Line 3</Label>
                <Input
                  id="buyerAddress3"
                  value={formState.buyerAddress3}
                  onChange={(e) => setField("buyerAddress3", e.target.value)}
                  placeholder="City, state, ZIP code"
                  disabled={isSubmitting}
                />
              </div>

              {/* SECTION: Shipping Address */}
              <SectionHeading title="Shipping Address" />

              <div>
                <Label htmlFor="shippingAddress1">Address Line 1 <span className="text-red-500">*</span></Label>
                <Input
                  id="shippingAddress1"
                  value={formState.shippingAddress1}
                  onChange={(e) => {
                    setField("shippingAddress1", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, shippingAddress1: undefined }));
                  }}
                  placeholder="Street address"
                  disabled={isSubmitting}
                  className={fieldErrors.shippingAddress1 ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.shippingAddress1 && <p className="mt-1 text-xs text-red-500">{fieldErrors.shippingAddress1}</p>}
              </div>

              <div>
                <Label htmlFor="shippingAddress2">Address Line 2</Label>
                <Input
                  id="shippingAddress2"
                  value={formState.shippingAddress2}
                  onChange={(e) => setField("shippingAddress2", e.target.value)}
                  placeholder="Apartment, suite, etc."
                  disabled={isSubmitting}
                />
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="shippingAddress3">Address Line 3</Label>
                <Input
                  id="shippingAddress3"
                  value={formState.shippingAddress3}
                  onChange={(e) => setField("shippingAddress3", e.target.value)}
                  placeholder="City, state, ZIP code"
                  disabled={isSubmitting}
                />
              </div>

              {/* SECTION: Tax & Compliance */}
              <SectionHeading title="Tax & Compliance" />

              <div>
                <Label htmlFor="cin">CIN</Label>
                <Input
                  id="cin"
                  value={formState.cin}
                  onChange={(e) => setField("cin", e.target.value)}
                  placeholder="Corporate Identification Number"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="gst">GST Number <span className="text-red-500">*</span></Label>
                <Input
                  id="gst"
                  value={formState.gst}
                  onChange={(e) => {
                    setField("gst", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, gst: undefined }));
                  }}
                  placeholder="GSTIN123456789"
                  disabled={isSubmitting}
                  className={fieldErrors.gst ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.gst && <p className="mt-1 text-xs text-red-500">{fieldErrors.gst}</p>}
              </div>

              <div>
                <Label htmlFor="pan">PAN <span className="text-red-500">*</span></Label>
                <Input
                  id="pan"
                  value={formState.pan}
                  onChange={(e) => {
                    setField("pan", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, pan: undefined }));
                  }}
                  placeholder="Permanent Account Number"
                  disabled={isSubmitting}
                  className={fieldErrors.pan ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.pan && <p className="mt-1 text-xs text-red-500">{fieldErrors.pan}</p>}
              </div>

              <div>
                <Label htmlFor="tan">TAN</Label>
                <Input
                  id="tan"
                  value={formState.tan}
                  onChange={(e) => setField("tan", e.target.value)}
                  placeholder="Tax Deduction Account Number"
                  disabled={isSubmitting}
                />
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="cGstLutNo">GST LUT Number</Label>
                <Input
                  id="cGstLutNo"
                  value={formState.cGstLutNo}
                  onChange={(e) => setField("cGstLutNo", e.target.value)}
                  placeholder="Letter of Undertaking Number"
                  disabled={isSubmitting}
                />
              </div>

              {/* GST LUT Expiry Date — UI-only, drives the expiry notification */}
              <div className="md:col-span-2">
                <Label htmlFor="lutExpiry">GST LUT Expiry Date</Label>
                <input
                  id="lutExpiry"
                  type="date"
                  value={lutExpiry}
                  onChange={(e) => setLutExpiry(e.target.value)}
                  disabled={isSubmitting}
                  className="h-10 w-full rounded-lg border border-gray-300 bg-white px-3 text-sm text-gray-800 outline-none transition-colors focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white disabled:opacity-50"
                />

                {/* ── Expiry notification strip ── */}
                {lutStatus.type === "expired" && (
                  <div className="mt-2 flex items-center gap-2 rounded-md border border-red-200 bg-red-50 px-3 py-2 dark:border-red-500/30 dark:bg-red-500/10">
                    <svg className="h-4 w-4 shrink-0 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm-.75-11.25a.75.75 0 011.5 0v4.5a.75.75 0 01-1.5 0v-4.5zm.75 7.5a.75.75 0 100-1.5.75.75 0 000 1.5z" clipRule="evenodd" />
                    </svg>
                    <span className="text-xs font-medium text-red-700 dark:text-red-400">
                      LUT expired {lutStatus.daysAgo} day{lutStatus.daysAgo !== 1 ? "s" : ""} ago — renew immediately to avoid compliance issues.
                    </span>
                  </div>
                )}

                {lutStatus.type === "warning" && (
                  <div className="mt-2 flex items-center gap-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 dark:border-amber-500/30 dark:bg-amber-500/10">
                    <svg className="h-4 w-4 shrink-0 text-amber-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                    </svg>
                    <span className="text-xs font-medium text-amber-700 dark:text-amber-400">
                      {lutStatus.daysLeft === 0
                        ? "LUT expires today — renew as soon as possible."
                        : `LUT expires in ${lutStatus.daysLeft} day${lutStatus.daysLeft !== 1 ? "s" : ""} — consider renewing soon.`}
                    </span>
                  </div>
                )}

                {lutStatus.type === "ok" && lutExpiry && (
                  <div className="mt-2 flex items-center gap-2 rounded-md border border-green-200 bg-green-50 px-3 py-2 dark:border-green-500/30 dark:bg-green-500/10">
                    <svg className="h-4 w-4 shrink-0 text-green-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clipRule="evenodd" />
                    </svg>
                    <span className="text-xs font-medium text-green-700 dark:text-green-400">
                      LUT is valid.
                    </span>
                  </div>
                )}
              </div>

              {/* SECTION: Bank Details (India) */}
              <SectionHeading title="Bank Details (India)" />

              <div>
                <Label htmlFor="bankAccHolder">Account Holder Name <span className="text-red-500">*</span></Label>
                <Input
                  id="bankAccHolder"
                  value={formState.bankAccHolder}
                  onChange={(e) => {
                    setField("bankAccHolder", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, bankAccHolder: undefined }));
                  }}
                  placeholder="Full name on bank account"
                  disabled={isSubmitting}
                  className={fieldErrors.bankAccHolder ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.bankAccHolder && <p className="mt-1 text-xs text-red-500">{fieldErrors.bankAccHolder}</p>}
              </div>

              <div>
                <Label htmlFor="bankName">Bank Name <span className="text-red-500">*</span></Label>
                <Input
                  id="bankName"
                  value={formState.bankName}
                  onChange={(e) => {
                    setField("bankName", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, bankName: undefined }));
                  }}
                  placeholder="e.g., HDFC Bank, ICICI Bank"
                  disabled={isSubmitting}
                  className={fieldErrors.bankName ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.bankName && <p className="mt-1 text-xs text-red-500">{fieldErrors.bankName}</p>}
              </div>

              <div>
                <Label htmlFor="accNumber">Account Number <span className="text-red-500">*</span></Label>
                <Input
                  id="accNumber"
                  value={formState.accNumber}
                  onChange={(e) => {
                    setField("accNumber", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, accNumber: undefined }));
                  }}
                  placeholder="Bank account number"
                  disabled={isSubmitting}
                  className={fieldErrors.accNumber ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.accNumber && <p className="mt-1 text-xs text-red-500">{fieldErrors.accNumber}</p>}
              </div>

              <div>
                <Label htmlFor="micrCode">MICR Code</Label>
                <Input
                  id="micrCode"
                  value={formState.micrCode}
                  onChange={(e) => setField("micrCode", e.target.value)}
                  placeholder="15 digits (e.g., 400016089)"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="ifscCode">
                  IFSC Code {formState.custType === "1" && <span className="text-red-500">*</span>}
                </Label>
                <Input
                  id="ifscCode"
                  value={formState.ifscCode}
                  onChange={(e) => {
                    setField("ifscCode", e.target.value.toUpperCase());
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, ifscCode: undefined }));
                  }}
                  placeholder="e.g., HDFC0000089"
                  maxLength={11}
                  disabled={isSubmitting}
                  className={fieldErrors.ifscCode ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  11 characters: Bank code (4) + 0 + Branch code (6)
                </p>
                {fieldErrors.ifscCode && <p className="mt-1 text-xs text-red-500">{fieldErrors.ifscCode}</p>}
              </div>

              {/* SECTION: International Bank Details */}
              <SectionHeading title="International Bank Details" />

              <div>
                <Label htmlFor="cSwiftCode">
                  SWIFT Code {formState.custType === "2" && <span className="text-red-500">*</span>}
                </Label>
                <Input
                  id="cSwiftCode"
                  value={formState.cSwiftCode}
                  onChange={(e) => {
                    setField("cSwiftCode", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, cSwiftCode: undefined }));
                  }}
                  placeholder="e.g., HDFCINBBXXX"
                  disabled={isSubmitting}
                  className={fieldErrors.cSwiftCode ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.cSwiftCode && <p className="mt-1 text-xs text-red-500">{fieldErrors.cSwiftCode}</p>}
              </div>

              <div>
                <Label htmlFor="cBankCode">
                  Bank Code {formState.custType === "2" && <span className="text-red-500">*</span>}
                </Label>
                <Input
                  id="cBankCode"
                  value={formState.cBankCode}
                  onChange={(e) => {
                    setField("cBankCode", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, cBankCode: undefined }));
                  }}
                  placeholder="International bank code"
                  disabled={isSubmitting}
                  className={fieldErrors.cBankCode ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.cBankCode && <p className="mt-1 text-xs text-red-500">{fieldErrors.cBankCode}</p>}
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="cIban">
                  IBAN {formState.custType === "2" && <span className="text-red-500">*</span>}
                </Label>
                <Input
                  id="cIban"
                  value={formState.cIban}
                  onChange={(e) => {
                    setField("cIban", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, cIban: undefined }));
                  }}
                  placeholder="International Bank Account Number"
                  disabled={isSubmitting}
                  className={fieldErrors.cIban ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.cIban && <p className="mt-1 text-xs text-red-500">{fieldErrors.cIban}</p>}
              </div>

              {/* SECTION: Bank Branch Address */}
              <SectionHeading title="Bank Branch Address" />

              <div>
                <Label htmlFor="cBankBranchAdd1">
                  Address Line 1 {formState.custType === "2" && <span className="text-red-500">*</span>}
                </Label>
                <Input
                  id="cBankBranchAdd1"
                  value={formState.cBankBranchAdd1}
                  onChange={(e) => {
                    setField("cBankBranchAdd1", e.target.value);
                    if (e.target.value.trim()) setFieldErrors((p) => ({ ...p, cBankBranchAdd1: undefined }));
                  }}
                  placeholder="Branch street address"
                  disabled={isSubmitting}
                  className={fieldErrors.cBankBranchAdd1 ? "border-red-500 ring-2 ring-red-500/20" : ""}
                />
                {fieldErrors.cBankBranchAdd1 && <p className="mt-1 text-xs text-red-500">{fieldErrors.cBankBranchAdd1}</p>}
              </div>

              <div>
                <Label htmlFor="cBankBranchAdd2">Address Line 2</Label>
                <Input
                  id="cBankBranchAdd2"
                  value={formState.cBankBranchAdd2}
                  onChange={(e) => setField("cBankBranchAdd2", e.target.value)}
                  placeholder="Apartment, suite, etc."
                  disabled={isSubmitting}
                />
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="cBankBranchAdd3">Address Line 3</Label>
                <Input
                  id="cBankBranchAdd3"
                  value={formState.cBankBranchAdd3}
                  onChange={(e) => setField("cBankBranchAdd3", e.target.value)}
                  placeholder="City, state, country, ZIP code"
                  disabled={isSubmitting}
                />
              </div>
            </div>

            {/* Form Actions */}
            <div className="mt-4 flex gap-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="inline-flex items-center justify-center rounded-md bg-brand-500 px-3 py-1.5 text-xs font-medium text-white hover:bg-brand-600 disabled:opacity-50"
              >
                {isSubmitting
                  ? "Saving..."
                  : isEditing
                    ? "Update Customer"
                    : "Create Customer"}
              </button>
              <button
                type="button"
                onClick={handleCancelForm}
                disabled={isSubmitting}
                className="inline-flex items-center justify-center rounded-md border border-gray-300 px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 dark:border-gray-700 dark:text-gray-300"
              >
                Cancel
              </button>
            </div>
          </form>
        </Modal>

        {/* Table */}
        <div className="overflow-x-auto rounded-lg border border-gray-200 dark:border-gray-800">
          <Table>
            <TableHeader className="bg-gray-50 dark:bg-white/[0.03]">
              <TableRow>
                {[
                  "ID",
                  "Company Name",
                  "Contact",
                  "Email",
                  "GST",
                  "Type",
                  "Status",
                  "Actions",
                ].map((h) => (
                  <TableCell
                    key={h}
                    isHeader
                    className="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide text-gray-600 dark:text-gray-300"
                  >
                    {h}
                  </TableCell>
                ))}
              </TableRow>
            </TableHeader>

            <TableBody className="divide-y divide-gray-100 dark:divide-gray-800">
              {isLoading && (
                <TableRow>
                  <TableCell
                    colSpan={8}
                    className="px-3 py-5 text-center text-xs text-gray-500 dark:text-gray-400"
                  >
                    <div className="flex items-center justify-center gap-2">
                      <svg
                        className="h-4 w-4 animate-spin text-brand-500"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8v8H4z"
                        />
                      </svg>
                      Loading customers…
                    </div>
                  </TableCell>
                </TableRow>
              )}

              {!isLoading && rows.length === 0 && (
                <TableRow>
                  <TableCell
                    colSpan={8}
                    className="px-3 py-5 text-center text-xs text-gray-500 dark:text-gray-400"
                  >
                    No customers found. Click &ldquo;Add Customer&rdquo; to create your first one.
                  </TableCell>
                </TableRow>
              )}

              {!isLoading &&
                rows.map((row) => (
                  <TableRow
                    key={row.id}
                    className="transition-colors hover:bg-brand-50/60 dark:hover:bg-brand-500/5"
                  >
                    <TableCell className="px-3 py-2 text-xs font-medium text-brand-600 dark:text-brand-400">
                      {row.id}
                    </TableCell>
                    <TableCell className="px-3 py-2 text-xs font-medium text-gray-800 dark:text-white">
                      {row.name || "—"}
                    </TableCell>
                    <TableCell className="px-3 py-2 text-xs text-gray-600 dark:text-gray-300">
                      {row.contact || "—"}
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate px-3 py-2 text-xs text-gray-600 dark:text-gray-300">
                      {row.gmailId || "—"}
                    </TableCell>
                    <TableCell className="px-3 py-2 text-sm font-mono text-gray-600 dark:text-gray-300">
                      {row.gst || "—"}
                    </TableCell>
                    <TableCell className="px-3 py-2">
                      <CustTypeBadge type={row.custType} />
                    </TableCell>
                    <TableCell className="px-3 py-2">
                      <StatusBadge status={row.status} />
                    </TableCell>
                    <TableCell
                      className="px-3 py-2 text-xs"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleOpenParties(row)}
                          title="View party contacts for this customer"
                          className="inline-flex items-center justify-center rounded-md border border-teal-300 px-3 py-1.5 text-xs font-medium text-teal-600 hover:bg-teal-50 disabled:opacity-50 dark:border-teal-700 dark:text-teal-400 dark:hover:bg-teal-500/10"
                        >
                          Parties
                        </button>
                        <button
                          type="button"
                          onClick={() => openEditForm(row)}
                          disabled={isSubmitting}
                          className="inline-flex items-center justify-center rounded-md border border-brand-300 px-2 py-1 text-xs font-medium text-brand-600 hover:bg-brand-50 disabled:opacity-50 dark:border-brand-800 dark:text-brand-300 dark:hover:bg-brand-500/10"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          onClick={() => void handleDelete(row.id!)}
                          disabled={isSubmitting}
                          className="inline-flex items-center justify-center rounded-md border border-error-300 px-2 py-1 text-xs font-medium text-error-600 hover:bg-error-50 disabled:opacity-50 dark:border-error-800 dark:text-error-400 dark:hover:bg-error-500/10"
                        >
                          Delete
                        </button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </div>

        {!isLoading && rows.length > 0 && (
          <p className="mt-4 text-xs text-gray-400 dark:text-gray-500">
            {rows.length} customer{rows.length !== 1 ? "s" : ""}
          </p>
        )}
      </ComponentCard>
    </>
  );
}