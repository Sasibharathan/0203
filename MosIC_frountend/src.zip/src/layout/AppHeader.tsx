import { useState } from "react";
import { CloseIcon, ListIcon } from "../icons";
import { useSidebar } from "../context/SidebarContext";
import { ThemeToggleButton } from "../components/common/ThemeToggleButton";

export default function AppHeader() {
  const { isMobileOpen, toggleMobileSidebar, toggleSidebar } = useSidebar();
  const [query, setQuery] = useState("");

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-gray-200 bg-white px-4 dark:border-gray-800 dark:bg-gray-900 md:px-6">
      <div className="flex min-w-0 items-center gap-3">
        {/* Mobile menu toggle */}
        <button
          type="button"
          onClick={toggleMobileSidebar}
          className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-700 hover:bg-gray-100 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-white/[0.06] lg:hidden"
          aria-label={isMobileOpen ? "Close menu" : "Open menu"}
          title={isMobileOpen ? "Close menu" : "Open menu"}
        >
          {isMobileOpen ? (
            <CloseIcon className="h-5 w-5" />
          ) : (
            <ListIcon className="h-5 w-5" />
          )}
        </button>

        {/* Desktop sidebar collapse/expand */}
        <button
          type="button"
          onClick={toggleSidebar}
          className="hidden h-10 w-10 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-700 hover:bg-gray-100 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:bg-white/[0.06] lg:inline-flex"
          aria-label="Toggle sidebar"
          title="Toggle sidebar"
        >
          <ListIcon className="h-5 w-5" />
        </button>

        {/* Search */}
        <div className="relative hidden w-full max-w-md sm:block">
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
            <svg
              className="h-4 w-4"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M10.5 18.5a8 8 0 1 1 0-16 8 8 0 0 1 0 16Z"
                stroke="currentColor"
                strokeWidth="2"
              />
              <path
                d="M16.5 16.5 21 21"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
          </span>
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search..."
            className="h-10 w-full rounded-lg border border-gray-200 bg-gray-50 pl-10 pr-4 text-sm text-gray-700 outline-none transition-colors focus:border-brand-500 focus:bg-white dark:border-gray-800 dark:bg-gray-900 dark:text-gray-200 dark:placeholder:text-gray-500 dark:focus:border-brand-400"
          />
        </div>
      </div>

      <div className="flex flex-shrink-0 items-center gap-2">
        <ThemeToggleButton />
      </div>
    </header>
  );
}
